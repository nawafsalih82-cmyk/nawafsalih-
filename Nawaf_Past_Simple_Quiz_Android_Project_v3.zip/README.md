Nawaf Past Simple Quiz - V2

Quiz app with larger Arabic/English text and a dark navy/gold game-show inspired interface.
Designer credit: الأستاذ نواف المتيوتي.
