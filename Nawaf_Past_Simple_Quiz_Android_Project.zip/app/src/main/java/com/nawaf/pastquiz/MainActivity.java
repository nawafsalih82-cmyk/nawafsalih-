package com.nawaf.pastquiz;

import android.app.Activity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.graphics.*;
import android.view.*;
import android.content.*;
import android.media.MediaPlayer;
import java.util.*;

public class MainActivity extends Activity {
    QuizView quizView;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(23,59,112));
        getWindow().setNavigationBarColor(Color.rgb(8,26,53));
        quizView = new QuizView(this);
        setContentView(quizView);
    }
    @Override protected void onDestroy() {
        if (quizView != null) quizView.stopTimer();
        super.onDestroy();
    }

    static class Q {
        String verb; String[] options; int correct;
        Q(String v, String[] o, int c){verb=v;options=o;correct=c;}
    }

    class QuizView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<Q> qs = new ArrayList<>();
        int index=0, score=0, selected=-1;
        long timeLeft=30000;
        CountDownTimer timer;
        boolean locked=false, finished=false;
        int feedbackColor=Color.TRANSPARENT;
        String feedbackText="";
        int blue=Color.rgb(23,59,112), green=Color.rgb(35,139,69), red=Color.rgb(198,40,40);

        QuizView(Context c) {
            super(c);
            qs.add(new Q("go",new String[]{"goes","went","going"},1));
            qs.add(new Q("do",new String[]{"does","doing","did"},2));
            qs.add(new Q("see",new String[]{"saw","seen","seed"},0));
            qs.add(new Q("write",new String[]{"writing","written","wrote"},2));
            qs.add(new Q("is",new String[]{"ised","was","ising"},1));
            qs.add(new Q("drink",new String[]{"drank","drunk","drinking"},0));
            qs.add(new Q("eat",new String[]{"eating","ate","ote"},1));
            qs.add(new Q("sleep",new String[]{"slept","sleeping","seelped"},0));
            qs.add(new Q("find",new String[]{"found","finded","finding"},0));
            qs.add(new Q("have",new String[]{"had","has","having"},0));
            startTimer();
        }

        void stopTimer(){ if(timer!=null) timer.cancel(); }
        void startTimer(){
            stopTimer(); timeLeft=30000;
            timer=new CountDownTimer(30000,1000){
                public void onTick(long ms){timeLeft=ms;invalidate();}
                public void onFinish(){timeLeft=0;if(!locked&&!finished) timeout();}
            }.start();
        }
        void timeout(){
            locked=true; feedbackColor=red; feedbackText="انتهى الوقت!";
            playSound("wrong"); invalidate();
            postDelayed(this::nextQuestion,1100);
        }
        void nextQuestion(){
            if(index>=qs.size()-1){finished=true;stopTimer();invalidate();return;}
            index++;selected=-1;locked=false;feedbackColor=Color.TRANSPARENT;feedbackText="";
            startTimer();invalidate();
        }
        void answer(int i){
            if(locked||finished)return;
            locked=true;selected=i;Q q=qs.get(index);
            if(i==q.correct){score++;feedbackColor=green;feedbackText="أحسنت! إجابة صحيحة 👏";playSound("applause");}
            else {feedbackColor=red;feedbackText="للأسف، إجابة غير صحيحة";playSound("wrong");}
            stopTimer();invalidate();postDelayed(this::nextQuestion,1100);
        }
        void restart(){index=0;score=0;selected=-1;locked=false;finished=false;feedbackColor=Color.TRANSPARENT;feedbackText="";startTimer();invalidate();}
        void playSound(String name){
            try {
                int id=getResources().getIdentifier(name,"raw",getPackageName());
                MediaPlayer mp=MediaPlayer.create(MainActivity.this,id);
                if(mp!=null){mp.setOnCompletionListener(MediaPlayer::release);mp.start();}
            } catch(Exception ignored){}
        }
        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align a){
            p.setStyle(Paint.Style.FILL);p.setShader(null);p.setColor(color);p.setTextSize(size);p.setTextAlign(a);
            p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);
        }
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){
            p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,p);
        }

        @Override protected void onDraw(Canvas c){
            int w=getWidth(),h=getHeight(); c.drawColor(Color.rgb(247,249,252));
            p.setShader(new LinearGradient(0,0,w,180,blue,Color.rgb(35,88,145),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,180,p);p.setShader(null);
            text(c,"نواف صالح",w-28,58,20,Color.WHITE,true,Paint.Align.RIGHT);
            text(c,"تصريف الأفعال في الماضي البسيط",w-28,100,24,Color.WHITE,true,Paint.Align.RIGHT);
            text(c,"تصميم الأستاذ نواف المتيوتي",w-28,137,15,Color.rgb(220,232,250),false,Paint.Align.RIGHT);

            if(finished){drawResult(c,w,h);return;}
            text(c,"السؤال "+(index+1)+" من "+qs.size(),w-28,215,17,blue,true,Paint.Align.RIGHT);
            float frac=timeLeft/30000f;
            round(c,28,232,w-28,248,8,Color.rgb(220,227,238));
            round(c,28,232,28+(w-56)*frac,248,8,frac<.25f?red:blue);
            text(c,String.format(Locale.US,"%02d",(int)Math.ceil(timeLeft/1000.0)),w/2f,294,36,frac<.25f?red:blue,true,Paint.Align.CENTER);
            text(c,"ثانية",w/2f,320,13,Color.DKGRAY,false,Paint.Align.CENTER);

            Q q=qs.get(index);
            round(c,20,350,w-20,510,24,Color.WHITE);
            text(c,"ما هو تصريف الفعل:",w/2f,388,18,Color.DKGRAY,true,Paint.Align.CENTER);
            text(c,q.verb,w/2f,455,42,blue,true,Paint.Align.CENTER);
            text(c,"Past Simple",w/2f,488,15,Color.GRAY,false,Paint.Align.CENTER);

            String[] letters={"A","B","C"};
            for(int i=0;i<3;i++){
                float top=535+i*78;
                int bg=Color.WHITE,border=Color.rgb(210,218,230);
                if(locked&&selected==i){bg=(i==q.correct)?green:red;border=bg;}
                else if(locked&&i==q.correct){bg=Color.rgb(224,246,229);border=green;}
                round(c,22,top,w-22,top+62,18,bg);
                stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(2);stroke.setColor(border);
                c.drawRoundRect(22,top,w-22,top+62,18,18,stroke);
                text(c,letters[i],52,top+40,19,(bg==green||bg==red)?Color.WHITE:blue,true,Paint.Align.CENTER);
                text(c,q.options[i],w-55,top+40,21,(bg==green||bg==red)?Color.WHITE:Color.rgb(35,45,60),true,Paint.Align.RIGHT);
            }
            if(!feedbackText.isEmpty()) text(c,feedbackText,w/2f,790,18,feedbackColor,true,Paint.Align.CENTER);
            text(c,"النتيجة: "+score,w-28,h-22,15,blue,true,Paint.Align.RIGHT);
        }

        void drawResult(Canvas c,int w,int h){
            text(c,"انتهى الاختبار 🎉",w/2f,290,30,blue,true,Paint.Align.CENTER);
            text(c,"نتيجتك",w/2f,365,18,Color.DKGRAY,false,Paint.Align.CENTER);
            text(c,score+" / "+qs.size(),w/2f,445,58,green,true,Paint.Align.CENTER);
            text(c,score>=9?"ممتاز جدًا! 🌟":score>=7?"أحسنت! استمر بالتدريب 👏":"حاول مرة أخرى وستتحسن 💪",w/2f,500,19,blue,true,Paint.Align.CENTER);
            round(c,60,560,w-60,630,20,blue);
            text(c,"إعادة الاختبار",w/2f,606,20,Color.WHITE,true,Paint.Align.CENTER);
            text(c,"تصميم الأستاذ نواف المتيوتي",w/2f,700,15,Color.GRAY,false,Paint.Align.CENTER);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float y=e.getY();
            if(finished){if(y>=540&&y<=650)restart();return true;}
            if(y>=535&&y<=597)answer(0);
            else if(y>=613&&y<=675)answer(1);
            else if(y>=691&&y<=753)answer(2);
            return true;
        }
    }
}
